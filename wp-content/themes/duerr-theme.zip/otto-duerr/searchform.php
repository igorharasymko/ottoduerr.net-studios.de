<form method="get" id="search_form" action="<?php echo home_url(); ?>">
<input class="text" type="text" value="Search..." onFocus="if(this.value==this.defaultValue)this.value='';" onBlur="if(this.value=='')this.value=this.defaultValue;"  name="s" id="s"  />
<input type="submit" id="searchsubmit" name="Submit" value="Search!" />
</form>
