<?php
//admin varibles in get_options
$timthumb=get_option('timthumb');
$slider_limits=get_option('sliderlimits');
$kaya_readmore=get_option('kaya_readmore') ? get_option('kaya_readmore') :'Read More';
?>