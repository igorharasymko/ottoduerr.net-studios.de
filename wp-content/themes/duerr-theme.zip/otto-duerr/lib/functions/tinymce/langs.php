<script type="text/javascript">
tinyMCE.addI18n({en:{
shortcode_kaya:{	
desc : 'Haya shortcodes'
}}});
</script>