<script type="text/javascript">
// slider Document
			jQuery(document).ready(function(){	
					var sudoSlider = jQuery("#vertical_slider").sudoSlider({
					   vertical:true,
					   continuous:true,
					   auto:false,
					   hoverPause:true,
					   speed:2000
					});
				});
	</script> 
<div id="vertical_slider_wrapper">
                    	<h3>Latest News</h3>
                        <div id="vertical_slider" >
                            <ul>
                                <li>
                                	<div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Jan</h5>
                                            <h4>24</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Donec tristique mauris</a></strong></p>
                                             <p>Morbi tempor sem et lacus placerat at auctor diam ornare. 
                                                tristique eget vel turpis...</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Mar</h5>
                                            <h4>1</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Bibendum varius iaculis.</a></strong></p>
                                             <p>Aenean tincidunt fermentum volutpat. 
                                             Vestibulum ante ipsum primis in faucibus....</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Apr</h5>
                                            <h4>12</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Urpis non viverra aliquam.</a></strong></p>
                                             <p>Elementum turpis non viverra aliquam
                                              eros urna dictum nisi id porttitor ....</p>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                	<div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Jul</h5>
                                            <h4>10</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Fringilla velit quis nisi.</a></strong></p>
                                             <p>Integer laoreet sapien non nulla commodo mollis. 
                                             Mauris in placerat lacus...</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Aug</h5>
                                            <h4>15</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Hendrerit sollicitudin.</a></strong></p>
                                             <p>Nam commodo lectus quis nisl dignissim lacinia. 
                                             Ut tempor luctus orci luctus eu...</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Sep</h5>
                                            <h4>29</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Lobortis urna scelerisque.</a></strong></p>
                                             <p>In varius odio sit amet dolor blandit vel  
                                             Phasellus congue faucibus eros fringilla.....</p>
                                        </div>
                                    </div>
                                </li>
                                
                                <li>
                                	<div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Oct</h5>
                                            <h4>5</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Sapien non nulla commodo.</a></strong></p>
                                             <p>Vestibulum ante ipsum primis in faucibus orci luctus et ultrices 
                                             posuere cubilia Curae Integer laoreet.....</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Dec</h5>
                                            <h4>5</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Turpis bibendum.</a></strong></p>
                                             <p>Cras ut orci sed turpis sodales dignissim. 
                                             Donec a massa vel nulla interdum varius vel nulla dignissim.....</p>
                                        </div>
                                    </div>
                                    
                                    <div class="latest_news_content">
                                        <div class="thumb calender">
                                            <h5>Jan</h5>
                                            <h4>1</h4>
                                        </div>
                                        <div class="description">
                                             <p><strong><a href="#">Orci luctus et ultrices.</a></strong></p>
                                             <p>Fusce vel interdum diam. Aenean tincidunt fermentum volutpat. 
                                             Vestibulum ante ipsum primis in faucibus  posuere cubilia.....</p>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                        </div>