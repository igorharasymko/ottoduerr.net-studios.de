<div class="slider">
    <!--start slider -->
    <div class="container">
        <div id="ca-container" class="ca-container" style="margin-top:20px;"> <img src="<?php echo get_template_directory_uri(); ?>/images/default_slider.png" width="959" height="350"> </div>
    </div>
</div>
