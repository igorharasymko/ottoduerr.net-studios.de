<link href="<?php echo get_template_directory_uri(); ?>/css/parallax.css" rel="stylesheet" type="text/css" />
<div class="slider">
  <!--start slider -->
  <div class="container">
    <div id="ca-container" class="ca-container" style="margin-top:20px;"> <?php echo get_option('videourl'); ?> </div>
  </div>
</div>
